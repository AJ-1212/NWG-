export class Registration {

    public userid:number=0;
    public name:string='';
    public mail:string='';
    public password:string='';
    
}
